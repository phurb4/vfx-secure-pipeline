import os


def handler(event, context):
    allowed = [d.strip().lower() for d in os.environ.get("ALLOWED_DOMAINS", "").split(",") if d.strip()]
    email = event.get("request", {}).get("userAttributes", {}).get("email", "")
    domain = email.rsplit("@", 1)[-1].lower() if "@" in email else ""
    if domain not in allowed:
        raise Exception("Sign-up not allowed for this email domain.")
    return event
