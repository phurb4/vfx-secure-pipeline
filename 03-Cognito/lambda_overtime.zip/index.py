import boto3

def handler(event, context):
    iam = boto3.client("iam", endpoint_url="http://localhost:4566", region_name="us-east-1")
    group_name = "vfx-overtime-access"
    users = iam.get_group(GroupName=group_name)["Users"]
    for user in users:
        iam.remove_user_from_group(GroupName=group_name, UserName=user["UserName"])
    return {"removidos": len(users)}
