import os
import boto3
from datetime import datetime, timezone

def handler(event, context):
    sns = boto3.client("sns", endpoint_url="http://localhost:4566", region_name="us-east-1")
    email = event["request"]["userAttributes"].get("email", "desconocido")
    cuando = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    try:
        sns.publish(
            TopicArn=os.environ["TOPIC_ARN"],
            Subject="Acceso de invitado - VFX Pipeline",
            Message="Entro un invitado. Email: " + email + " - Momento: " + cuando,
        )
    except Exception as e:
        print("No se pudo publicar en SNS: " + str(e))
    return event
